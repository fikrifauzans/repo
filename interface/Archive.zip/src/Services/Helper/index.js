import Transform from './transform'
class Helper {




}

Object.assign(Helper.prototype, Transform)

export default Helper
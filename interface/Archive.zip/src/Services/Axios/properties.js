export default {
  token: null,
  headers: {},
}

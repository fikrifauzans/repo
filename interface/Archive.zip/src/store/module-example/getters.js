export function someGetter (/* state */) {
}
